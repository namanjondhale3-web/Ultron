package com.example.jarvis

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

class JarvisService : AccessibilityService() {
    companion object { var instance: JarvisService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }

    private fun find(pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        fun walk(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (pred(n)) return n
            for (i in 0 until n.childCount) walk(n.getChild(i))?.let { return it }
            return null
        }
        return walk(rootInActiveWindow)
    }
    private fun label(n: AccessibilityNodeInfo) = "${n.text ?: ""} ${n.contentDescription ?: ""}"

    // What Jarvis "sees": visible texts, marked [tap] / [input].
    fun screen(): String {
        val sb = StringBuilder(); var count = 0
        fun walk(x: AccessibilityNodeInfo?) {
            if (x == null || count > 120) return
            val t = label(x).trim()
            if (t.isNotEmpty() || x.isEditable) {
                sb.append(if (x.isEditable) "[input] " else if (x.isClickable) "[tap] " else "").append(t).append('\n'); count++
            }
            for (i in 0 until x.childCount) walk(x.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString()
    }

    fun open(name: String): String {
        val m = packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(packageManager).toString().contains(name, true) } ?: return "app not found"
        val pkg = m.activityInfo.packageName
        val i = packageManager.getLaunchIntentForPackage(pkg) ?: return "cannot open"
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { return "blocked: ${e.message}" }
        for (k in 0 until 8) {   // wait up to ~4s for the app to reach the screen
            Thread.sleep(500)
            if (rootInActiveWindow?.packageName?.toString() == pkg) return "opened"
        }
        return "not opened: Android blocked it (allow 'Display over other apps' for Ultron)"
    }

    // Taps the app's Search button (twice: tab, then bar) and types the query.
    fun searchIn(q: String) {
        val h = Handler(Looper.getMainLooper())
        h.post { act(JSONObject().put("type", "click").put("target", "search")) }
        h.postDelayed({ act(JSONObject().put("type", "click").put("target", "search")) }, 1500)
        h.postDelayed({ act(JSONObject().put("type", "type").put("text", q).put("submit", true)) }, 3000)
    }

    fun act(a: JSONObject): String {
        val target = a.optString("target")
        return when (a.optString("type")) {
            "open_app" -> open(target)
            "click" -> find { label(it).contains(target, true) }?.let {
                var n: AccessibilityNodeInfo? = it
                while (n != null && !n.isClickable) n = n.parent
                (n ?: it).performAction(AccessibilityNodeInfo.ACTION_CLICK); "clicked"
            } ?: "not found on screen"
            "type" -> {
                val f = find { it.isEditable && it.isFocused } ?: find { it.isEditable } ?: return "no input field"
                val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                if (a.optBoolean("submit") && Build.VERSION.SDK_INT >= 30)
                    f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                "typed"
            }
            "scroll" -> if (find { it.isScrollable }?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true) "scrolled" else "nothing to scroll"
            "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); "back" }
            "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); "home" }
            else -> "unknown action"
        }
    }
}
