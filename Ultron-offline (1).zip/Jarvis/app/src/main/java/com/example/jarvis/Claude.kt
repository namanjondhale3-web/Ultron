package com.example.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Claude {
    // Pulls the real key out of whatever was pasted (Gemini: AIza... or new AQ...; removes spaces/newlines/code).
    private fun clean(k: String) =
        Regex("""(AIza[\w-]{20,}|AQ\.[\w.-]{20,})""").find(k)?.value ?: k.filter { !it.isWhitespace() }

    // Claude keys start with "sk-ant"; anything else is treated as a Gemini key.
    fun ask(key0: String, system: String, msgs: JSONArray): String {
        val key = clean(key0)
        return if (key.startsWith("sk-ant")) claude(key, system, msgs) else gemini(key, system, msgs)
    }

    private var good: String? = null   // model that worked last time (tried first)

    private fun gemini(key: String, system: String, msgs: JSONArray): String {
        val contents = JSONArray()
        for (i in 0 until msgs.length()) {
            val m = msgs.getJSONObject(i)
            contents.put(JSONObject().put("role", if (m.getString("role") == "assistant") "model" else "user")
                .put("parts", JSONArray().put(JSONObject().put("text", m.getString("content")))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("maxOutputTokens", 300))
        val deadline = System.currentTimeMillis() + 32_000
        var err = ""
        for (attempt in 0 until 2) {
            for (model in listOf(good, "gemini-flash-lite-latest", "gemini-flash-latest", "gemini-3.6-flash").filterNotNull().distinct()) {
                if (System.currentTimeMillis() > deadline) break
                var resp = ""
                try {
                    val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                    c.connectTimeout = 6000; c.readTimeout = 18000      // a slow/busy server never hangs the app
                    c.requestMethod = "POST"; c.doOutput = true
                    c.setRequestProperty("content-type", "application/json")
                    c.setRequestProperty("x-goog-api-key", key)
                    c.outputStream.use { it.write(body.toString().toByteArray()) }
                    resp = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
                    val out = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                        .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                    good = model; return out
                } catch (e: Exception) {
                    if (model == good) good = null
                    err = "$model: " + resp.ifEmpty { e.message ?: "error" }.take(140)
                }
            }
            if (System.currentTimeMillis() > deadline) break
            Thread.sleep(600)
        }
        throw Exception(err)
    }

    private fun claude(key: String, system: String, msgs: JSONArray): String {
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", system).put("messages", msgs)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 30000
        c.requestMethod = "POST"; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("x-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        val j = JSONObject(resp)
        if (!j.has("content")) throw Exception(resp.take(150))
        return j.getJSONArray("content").getJSONObject(0).getString("text")
    }

    fun json(t: String) = JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
}
